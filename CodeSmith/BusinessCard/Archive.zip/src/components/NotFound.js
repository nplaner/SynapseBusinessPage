import React from "react";

const NotFound = () => {
  return <h1>Nothing here</h1>;
};

export default NotFound;
