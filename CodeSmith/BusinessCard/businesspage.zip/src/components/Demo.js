import React from "react";

const Demo = () => {
  return (
    <iframe
      src="http://synapsev4.eba-ygvxqwqd.us-east-2.elasticbeanstalk.com/login"
      title="docsiFrame"
      width="100%"
      height="100%"
      marginWidth="0"
      marginHeight="0"
      frameBorder="0"
    />
  );
};

export default Demo;
