import React from "react";

const Docs = () => {
  console.log("tutorial");
  return (
    <iframe
      src="https://oslabs-beta.github.io/synapse/index.html"
      title="docsiFrame"
      width="100%"
      height="100%"
      marginWidth="0"
      marginHeight="0"
      frameBorder="0"
    />
  );
};

export default Docs;
